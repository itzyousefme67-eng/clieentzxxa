package cc.silk.gui;

import cc.silk.gui.components.ColorPicker;
import cc.silk.gui.events.GuiEventHandler;
import cc.silk.module.setting.ColorSetting;
import cc.silk.gui.theme.Theme;
import cc.silk.gui.theme.ThemeManager;
import cc.silk.module.modules.client.ClickGUIModule;
import net.minecraft.client.gui.DrawContext;

import java.awt.*;
import java.util.Map;

public class ColorPickerManager {
    private final GuiEventHandler eventHandler;

    private static Color applyAlpha(Color c, int alpha) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, alpha)));
    }

    public ColorPickerManager(GuiEventHandler eventHandler) {
        this.eventHandler = eventHandler;
    }

    public void renderColorPickerPanel(DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY) {
        if (!eventHandler.isAnyColorPickerExpanded()) return;

        Theme theme = ThemeManager.getTheme(ClickGUIModule.theme.getMode());
        context.fill(x, y, x + width, y + height, applyAlpha(theme.panelBg(), 240).getRGB());
        int borderC = applyAlpha(theme.muted(), 200).getRGB();
        context.fill(x, y, x + width, y + 1, borderC);
        context.fill(x, y + height - 1, x + width, y + height, borderC);
        context.fill(x, y, x + 1, y + height, borderC);
        context.fill(x + width - 1, y, x + width, y + height, borderC);

        context.drawTextWithShadow(net.minecraft.client.MinecraftClient.getInstance().textRenderer, "Color Pickers", x + 10, y + 10, theme.text().getRGB());

        int currentY = y + 35;
        int panelPadding = 10;

        for (Map.Entry<ColorSetting, ColorPicker> entry : eventHandler.getColorPickers().entrySet()) {
            ColorSetting colorSetting = entry.getKey();
            ColorPicker colorPicker = entry.getValue();

            if (eventHandler.getColorPickerExpanded().getOrDefault(colorSetting, false)) {
        context.drawTextWithShadow(net.minecraft.client.MinecraftClient.getInstance().textRenderer, colorSetting.getName(),
            x + panelPadding, currentY, theme.text().getRGB());
                currentY += 20;

                int pickerHeight = Math.max(200, colorPicker.getTotalHeight());

                if (currentY + pickerHeight > y + height - panelPadding) {
                    pickerHeight = y + height - panelPadding - currentY;
                }

                if (pickerHeight > 50) {
                    int clipLeft = x + panelPadding;
                    int clipTop = currentY;
                    int clipRight = x + width - panelPadding;
                    int clipBottom = y + height - panelPadding;
                    context.enableScissor(clipLeft, clipTop, clipRight, clipBottom);
                    colorPicker.render(context, x + panelPadding, currentY, mouseX, mouseY);
                    context.disableScissor();
                }

                currentY += pickerHeight + 15;

                if (currentY < y + height - 50) {
            context.fill(x + panelPadding, currentY, x + width - panelPadding, currentY + 1,
                applyAlpha(theme.muted(), 160).getRGB());
                    currentY += 10;
                }
            }
        }
    }

    public boolean handleColorPickerClicks(double mouseX, double mouseY, int button) {
        if (!eventHandler.isAnyColorPickerExpanded()) return false;

        for (Map.Entry<ColorSetting, ColorPicker> entry : eventHandler.getColorPickers().entrySet()) {
            ColorSetting colorSetting = entry.getKey();
            ColorPicker colorPicker = entry.getValue();

            if (eventHandler.getColorPickerExpanded().getOrDefault(colorSetting, false)) {
                if (colorPicker.mouseClicked(mouseX, mouseY, button)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean handleColorPickerDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!eventHandler.isAnyColorPickerExpanded()) return false;

        for (Map.Entry<ColorSetting, ColorPicker> entry : eventHandler.getColorPickers().entrySet()) {
            ColorSetting colorSetting = entry.getKey();
            ColorPicker colorPicker = entry.getValue();

            if (eventHandler.getColorPickerExpanded().getOrDefault(colorSetting, false)) {
                if (colorPicker.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean handleColorPickerRelease(double mouseX, double mouseY, int button) {
        if (!eventHandler.isAnyColorPickerExpanded()) return false;

        for (Map.Entry<ColorSetting, ColorPicker> entry : eventHandler.getColorPickers().entrySet()) {
            ColorSetting colorSetting = entry.getKey();
            ColorPicker colorPicker = entry.getValue();

            if (eventHandler.getColorPickerExpanded().getOrDefault(colorSetting, false)) {
                if (colorPicker.mouseReleased(mouseX, mouseY, button)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean handleColorPickerKeyPress(int keyCode) {
        if (!eventHandler.isAnyColorPickerExpanded()) return false;
        boolean handled = false;
        for (Map.Entry<ColorSetting, ColorPicker> entry : eventHandler.getColorPickers().entrySet()) {
            ColorSetting colorSetting = entry.getKey();
            ColorPicker colorPicker = entry.getValue();
            if (eventHandler.getColorPickerExpanded().getOrDefault(colorSetting, false)) {
                try {
                    java.lang.reflect.Method m = ColorPicker.class.getDeclaredMethod("keyPressed", int.class);
                    m.setAccessible(true);
                    handled = (boolean) m.invoke(colorPicker, keyCode) || handled;
                } catch (Throwable ignored) {
                }
            }
        }
        return handled;
    }

    public boolean handleColorPickerCharTyped(char chr) {
        if (!eventHandler.isAnyColorPickerExpanded()) return false;
        boolean handled = false;
        for (Map.Entry<ColorSetting, ColorPicker> entry : eventHandler.getColorPickers().entrySet()) {
            ColorSetting colorSetting = entry.getKey();
            ColorPicker colorPicker = entry.getValue();
            if (eventHandler.getColorPickerExpanded().getOrDefault(colorSetting, false)) {
                try {
                    java.lang.reflect.Method m = ColorPicker.class.getDeclaredMethod("charTyped", char.class);
                    m.setAccessible(true);
                    handled = (boolean) m.invoke(colorPicker, chr) || handled;
                } catch (Throwable ignored) {
                }
            }
        }
        return handled;
    }
}