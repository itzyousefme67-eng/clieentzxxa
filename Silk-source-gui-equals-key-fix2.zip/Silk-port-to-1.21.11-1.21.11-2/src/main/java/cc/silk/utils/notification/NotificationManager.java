package cc.silk.utils.notification;

import cc.silk.module.Module;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

public class NotificationManager {
    private static final NotificationManager INSTANCE = new NotificationManager();
    private static final long DEFAULT_DURATION = 3000;
    @Getter
    private final List<Notification> notifications = new ArrayList<>();

    public static NotificationManager getInstance() {
        return INSTANCE;
    }

    public void addModuleNotification(Module module, boolean enabled) {
        String title = module.getName();
        String message = enabled ? "Enabled" : "Disabled";
        Notification.NotificationType type = enabled ?
                Notification.NotificationType.MODULE_ENABLED :
                Notification.NotificationType.MODULE_DISABLED;

        Notification notification = new Notification(title, message, type, DEFAULT_DURATION);
        notifications.add(notification);
    }

    public void addBuffExpiredNotification(String buffName) {
        String title = "rebuff";
        String message = buffName;
        Notification notification = new Notification(title, message, Notification.NotificationType.BUFF_EXPIRED, DEFAULT_DURATION);
        notifications.add(notification);
    }
}