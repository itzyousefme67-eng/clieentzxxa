package cc.silk.mixin;

import cc.silk.SilkClient;
import cc.silk.module.modules.movement.KeepSprint;
import cc.silk.module.modules.player.FastMine;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {

    @Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true)
    private void modifyBlockBreakingSpeed(BlockState block, CallbackInfoReturnable<Float> cir) {
        if (SilkClient.INSTANCE == null) return;

        Optional<FastMine> optionalModule = SilkClient.INSTANCE.getModuleManager().getModule(FastMine.class);
        if (optionalModule.isEmpty()) return;

        FastMine fastMine = optionalModule.get();
        if (!fastMine.isEnabled()) return;

        PlayerEntity player = (PlayerEntity) (Object) this;
        if (player != MinecraftClient.getInstance().player) return;

        float modifiedSpeed = cir.getReturnValue() * fastMine.getSpeed();
        cir.setReturnValue(modifiedSpeed);
    }

    @Inject(method = "attack", at = @At("TAIL"))
    private void attackInject(Entity target, CallbackInfo ci) {
        if (SilkClient.INSTANCE == null) return;
        Optional<KeepSprint> keep = SilkClient.INSTANCE.getModuleManager().getModule(KeepSprint.class);
        if (keep.isEmpty()) return;
        KeepSprint keepSprint = keep.get();
        if (keepSprint.isEnabled()) {
            ((PlayerEntity)(Object)this).setSprinting(true);
        }
    }
}
